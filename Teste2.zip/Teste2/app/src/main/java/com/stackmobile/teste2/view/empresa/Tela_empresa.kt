package com.stackmobile.teste2.view.empresa

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.firebase.firestore.FirebaseFirestore
import com.stackmobile.teste2.R
import com.stackmobile.teste2.databinding.ActivityTelaClienteBinding
import com.stackmobile.teste2.databinding.ActivityTelaEmpresaBinding
import com.stackmobile.teste2.view.formlogin.form_login


class Tela_empresa : AppCompatActivity() {

    lateinit var binding: ActivityTelaEmpresaBinding
    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityTelaEmpresaBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBuscar.setOnClickListener {
            db.collection("Clientes").document("luiz@luiz.com")
                .addSnapshotListener { servico, error ->
                    if (servico != null) {
                        binding.txtResultado.text = servico.getString("Serviço")

                    }
                }
        }

        binding.btnVoltar.setOnClickListener {
            val voltar = Intent(this, form_login::class.java)
            startActivity(voltar)
            finish()
        }
    }
}