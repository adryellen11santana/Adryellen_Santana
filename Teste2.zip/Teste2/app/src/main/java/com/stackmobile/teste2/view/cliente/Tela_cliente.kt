package com.stackmobile.teste2.view.cliente

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.firestore.FirebaseFirestore
import com.stackmobile.teste2.R
import com.stackmobile.teste2.databinding.ActivityTelaClienteBinding
import com.stackmobile.teste2.view.formlogin.form_login

class Tela_cliente : AppCompatActivity() {

    lateinit var binding: ActivityTelaClienteBinding
    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTelaClienteBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnSalvar.setOnClickListener {

            val clientesMap = hashMapOf(
                "Nome" to binding.editNome.text.toString(),
                "Telefone" to binding.editTelefone.text.toString(),
                "Email" to binding.editEmailCliente.text.toString(),
                "Senha" to binding.editSenhaCliente.text.toString(),
                "Serviço" to binding.editServico.text.toString()
            )

            db.collection("Clientes").document(binding.editEmailCliente.text.toString())
                .set(clientesMap).addOnCompleteListener{
                    Log.d("db", "Dados salvos com sucesso!")

                    val snackbar = Snackbar.make(
                        binding.root,
                        "Dados salvos com sucesso!",
                        Snackbar.LENGTH_SHORT
                    ).also {
                        it.setBackgroundTint(Color.BLUE)
                        it.show()
                    }
                    binding.editNome.setText("")
                    binding.editTelefone.setText("")
                    binding.editServico.setText("")
                    binding.editEmailCliente.setText("")
                    binding.editSenhaCliente.setText("")

                }.addOnFailureListener{

                }

        }

        binding.btnVoltar.setOnClickListener {
            val voltar = Intent(this, form_login::class.java)
            startActivity(voltar)
            finish()
        }
    }
}